import { Component } from '@angular/core';

import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-banking',
  templateUrl: './banking.component.html',
  styleUrls: ['./banking.component.css']
})
export class BankingComponent {
  public FormGroup: any;
  public obj: any;
  public get addbankForm(): FormGroup {
    return this._addbankForm;
  }

  constructor(private _formBuilder: FormBuilder) {
    this._addbankForm = this._formBuilder.group({
      BankName: [null, Validators.compose(
        [
          Validators.required,
          Validators.minLength(2),
          Validators.pattern('^[A-Za-z\\s]+$'),
          Validators.maxLength(15)])],
      BranchName: [null, Validators.compose(
        [
          Validators.required,
          Validators.minLength(2),
          Validators.pattern('^[a-zA-Z_ ]*$'),
          Validators.maxLength(20)])],
      IFSCCode: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[A-Z]{4}[0][A-Z0-9]{6}')])],
      BankId: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{4,6}$')])],
    });
  }

  submitted = false;

  private _addbankForm: FormGroup;

  onSubmit() {
    this.submitted = true;
  }


  // tslint:disable-next-line:variable-name
  get(_FormGroup, _bankId: any) {
    this.FormGroup.controls.get('/assets/bankDetails.json').setvelue(this.obj.bankId);
  }
}
