import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NavigationComponent } from './navigation/navigation.component';
import { LoginComponent } from './login/login.component';
import { HelpComponent } from './help/help.component';
import { AboutComponent } from './about/about.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AddUserComponent } from './add-user/add-user.component';
import { BankingComponent } from './banking/banking.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { MakeTransactionComponent } from './make-transaction/make-transaction.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddBankComponent } from './add-bank/add-bank.component';
import { ViewBanksComponent } from './view-banks/view-banks.component';
import { ViewuserComponent } from './viewuser/viewuser.component';

import { AppMaterialModule } from '/home/nagaraju/PPA/src/app/app-materials/app-material.module';
import { ForgotComponent } from './forgot/forgot.component';
import { ProcessingComponent } from './processing/processing.component';
import { AddmoneyComponent } from './addmoney/addmoney.component';



@NgModule({
  declarations: [
    AppComponent,

    HeaderComponent,
    FooterComponent,
    NavigationComponent,
    LoginComponent,
    HelpComponent,
    AboutComponent,
    ContactusComponent,
    AddUserComponent,
    BankingComponent,
    TransactionsComponent,
    MakeTransactionComponent,
    DashboardComponent,
    AddBankComponent,
    ViewBanksComponent,
    ViewuserComponent,
    ForgotComponent,
    ProcessingComponent,
    AddmoneyComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,

    AppMaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
