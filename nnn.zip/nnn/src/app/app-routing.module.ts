import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { AboutComponent } from './about/about.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HelpComponent } from './help/help.component';
import { NavigationComponent } from './navigation/navigation.component';
import { BankingComponent } from './banking/banking.component';
import { AddBankComponent } from './add-bank/add-bank.component';
import { ViewBanksComponent } from './view-banks/view-banks.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { ViewuserComponent } from './viewuser/viewuser.component';
import { AddUserComponent } from './add-user/add-user.component';
import { MakeTransactionComponent } from './make-transaction/make-transaction.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FooterComponent } from './footer/footer.component';
import { ProcessingComponent } from './processing/processing.component';
import { ForgotComponent } from './forgot/forgot.component';
import { AddmoneyComponent } from './addmoney/addmoney.component';

const appRoutes: Routes = [
  { path: 'Login', component: LoginComponent },
  { path: 'About', component: AboutComponent },
  { path: 'ContactUs', component: ContactusComponent },
  { path: 'ContactUs/thankyou', component: FooterComponent },
  { path: 'Help?', component: HelpComponent },
  { path: 'Admin', component: NavigationComponent },
  { path: 'Banking/Add Bank', component: BankingComponent },
  { path: 'Add Bank', component: AddBankComponent },
  { path: 'Banking/View Banks', component: ViewBanksComponent },
  { path: 'Transactions', component: TransactionsComponent },
  { path: 'User Services/Add User', component: AddUserComponent },
  { path: 'User Services/Viewuser', component: ViewuserComponent },
  { path: 'Make A Transaction', component: MakeTransactionComponent },
  { path: 'Dashboard', component: DashboardComponent },
  { path: 'Processing', component: ProcessingComponent },
  { path: 'Forgot', component: ForgotComponent } ,
  { path: 'addMoney', component: AddmoneyComponent } ,
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
