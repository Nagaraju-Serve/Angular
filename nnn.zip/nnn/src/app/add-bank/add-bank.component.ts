import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-bank',
  templateUrl: './add-bank.component.html',
  styleUrls: ['./add-bank.component.css']
})
export class AddBankComponent implements OnInit {

  public bankname: string;
  public branchname: string;
  public ifsccode: string;

  constructor() { }

  ngOnInit() {
  }


  AddData() {
    console.log('Name: ', this.bankname, 'Password: ', this.branchname, 'IFSC Code: ', this.ifsccode);
  }

}
