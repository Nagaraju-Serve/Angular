import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-make-transaction',
  templateUrl: './make-transaction.component.html',
  styleUrls: ['./make-transaction.component.css']
})
export class MakeTransactionComponent implements OnInit {
  submitted = false;

  FromCurrency = ['Rupee', 'Euro', 'Dollar'];
  ToCurrency = ['Rupee', 'Euro', 'Dollar'];
  private _maketransactionForm: FormGroup;
  public get maketransactionForm(): FormGroup {
    return this._maketransactionForm;
  }

  constructor(private _formBuilder: FormBuilder) {
    this._maketransactionForm = this._formBuilder.group({
      PayeeAccountNo: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{11,14}$')])],
      BeneficiaryAccountNo: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{11,14}$')])],
      PayeeIFSCCode: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[A-Z]{4}[0][A-Z0-9]{6}')])],
      TransferAmt: [null],
      FromCurrency: [null],
      ToCurrency: [null],

    });
  }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
  }

}
