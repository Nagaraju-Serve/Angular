import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-addmoney',
  templateUrl: './addmoney.component.html',
  styleUrls: ['./addmoney.component.css']
})
export class AddmoneyComponent implements OnInit {
  submitted = false;
  Currency = ['Rupee', 'Euro', 'Dollar'];
  private _addMoneyForm: FormGroup;
  public get addMoneyForm(): FormGroup {
    return this._addMoneyForm;
  }

  constructor(private _formBuilder: FormBuilder) {
    this._addMoneyForm = this._formBuilder.group({
      UserId: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{4,6}$')])],
      Amount: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{1,6}$')])],
      Currency: [null],
    });
  }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
  }
}
