import { Component, OnInit } from '@angular/core';

import { Heros } from '../heros';
import { Validators } from '@angular/forms';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  model = new Heros(42,
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ',
    ' ');
  submitted = false;

  AccountType = ['Savings', 'Current', 'Zero'];
  AccountStatus = ['Active', 'Inactive'];

  private _adduserForm: FormGroup;
  public get adduserForm(): FormGroup {
    return this._adduserForm;
  }

  constructor(private _formBuilder: FormBuilder) {
    this._adduserForm = this._formBuilder.group({
      UserName: [null, Validators.compose(
        [
          Validators.required,
          Validators.minLength(4),
          Validators.pattern('^[a-zA-Z0-9_ ]*[a-zA-Z0-9_\\s\\-]*[a-zA-Z0-9_ ]*(?<![_\\s\\-]{2,})$'),
          Validators.maxLength(20)])],
      Password: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,15}$')])],

      AccountNo: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{11,14}$')])],
      HNO: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[a-zA-Z0-99\\d-_/ ]+$')])],
      Street: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[a-zA-Z0-99\\d-_/ ]+$')])],
      MobileNo: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[789]\\d{9}$')])],
      UserId: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{4,6}$')])],
      AccountType: [null],
      AccountStatus: [null],
      ConfirmAccountNo: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{11,14}$')])],
      CityVillage: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[a-zA-Z_ ]*$')])],
      State: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[a-zA-Z_ ]*$')])],
      Country: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[a-zA-Z_ ]*$')])],
      Pincode: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[1-9]{1}[0-9]{5}$')])],
      AccountHolderName: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[a-zA-Z_ ]*$'),
          Validators.minLength(4),
          Validators.maxLength(20)])],
      BankName: [null, Validators.compose(
        [
          Validators.required,
          Validators.minLength(2),
          Validators.pattern('^[A-Za-z\\s]+$'),
          Validators.maxLength(15)])],
      IFSCCode: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[A-Z]{4}[0][A-Z0-9]{6}')])],
      BranchName: [null, Validators.compose(
        [
          Validators.required,
          Validators.minLength(2),
          Validators.pattern('^[a-zA-Z_ ]*$'),
          Validators.maxLength(20)])]
    });
  }


  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
  }

}

