import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-viewuser',
    templateUrl: './viewuser.component.html',
    styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {

    User: any;
    constructor(private httpClient: HttpClient) { }

    ngOnInit() { this.get(); }

    get() {
        this.httpClient.get('http://172.16.16.39:8080/ip-endpoints/payout/user/allUsers').subscribe(User => {
            if (User && User) {
                this.User = User;
            }
        });
    }

}
