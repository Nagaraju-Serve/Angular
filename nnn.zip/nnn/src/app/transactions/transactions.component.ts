import { Component } from '@angular/core';

import { Validators, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent {
  submitted = false;
  Currency = ['Success', 'Pending', 'Failed'];
  private _transactionsForm: FormGroup;
  public get transactionsForm(): FormGroup {
    return this._transactionsForm;
  }

  constructor(private _formBuilder: FormBuilder) {
    this._transactionsForm = this._formBuilder.group({
      BankAccountNo: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^[0-9]{11,14}$')])],
      Currency: [null],
      fromDate: [null],
      toDate: [null],
    });
  }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
  }

}

