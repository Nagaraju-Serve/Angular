import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  toggle() {
    const main = document.getElementById('menu1');
    if (main.style.display === 'block') {
      main.style.display = 'none';
    } else {
      main.style.display = 'block';
    }
  }

  toggleClass() {
    const main1 = document.getElementById('menu3');
    if (main1.style.display === 'block') {
      main1.style.display = 'none';
    } else {
      main1.style.display = 'block';
    }
  }
}




