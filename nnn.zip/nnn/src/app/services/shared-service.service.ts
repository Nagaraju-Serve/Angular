import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {
  res: any;
  constructor(private http: HttpClient) { }

  getData() {
    return this.http.get('').pipe(map(res => {
      this.res = res;
      console.log(this.res);
    }));
  }
}
