import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseAPIClass } from '/home/nagaraju/PPA/src/app/services/core/class/baseAPI.class';

@Injectable()
export class BankService extends BaseAPIClass {
  
  constructor(protected httpClient: HttpClient) {
    super(httpClient);
    this.baseUrl = 'https://localhost:4200/api/bank';
  }
}
