/* import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class DataService {
  dataarray = [];
  constructor( private http: HttpClient ) { }

getData() {
return this.http.get('').map( res => {
    return res.json();
  });
}

}

 */