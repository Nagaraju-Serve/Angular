export const appLitterals = {
    THIS_FIELD_REQUIRED_TEXT: 'This field is required',
};
