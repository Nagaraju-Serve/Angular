import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public get loginForm(): FormGroup {
    return this._loginForm;
  }
  // tslint:disable-next-line:variable-name
  constructor(private _formBuilder: FormBuilder) {
    this._loginForm = this._formBuilder.group({
      userName: [null, Validators.compose(
        [
          Validators.required,
          Validators.minLength(4),
          Validators.pattern('^[a-zA-Z0-9_ ]*[a-zA-Z0-9_\\s\\-]*[a-zA-Z0-9_ ]*(?<![_\\s\\-]{2,})$'),
          Validators.maxLength(20)])],
      Password: [null, Validators.compose(
        [
          Validators.required,
          Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,15}$')])]
        });
      }
  // tslint:disable-next-line:variable-name
  private _loginForm: FormGroup;

  ngOnInit() {

  }

}
