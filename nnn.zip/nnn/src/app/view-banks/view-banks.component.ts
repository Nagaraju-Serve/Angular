import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-transactions',
    templateUrl: './view-banks.component.html',
    styleUrls: ['./view-banks.component.css']
})
export class ViewBanksComponent implements OnInit {
   public User: any;
    constructor(private httpClient: HttpClient) { }

    ngOnInit() { this.get(); }

    get() {
        this.httpClient.get('/assets/bankDetails.json').subscribe(User => {
            if (User && User) {
                this.User = User;
            }
        });
    }
}

