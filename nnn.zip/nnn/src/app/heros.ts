export class Heros {

  constructor(
    public id: number,
    public UserName: string,
    public Password: string,
    public MobileNo: string,
    public EMail: string,
    public HNO: string,
    public Street: string,
    public CityVillage: string,
    public State: string,
    public Pincode: string,
    public BankName?: string,
    public BranchName?: string,
    public IFSCCode?: string,
    public AccountHolderName?: string,
    public AccountNo?: string,
    public ConfirmAccountNo?: string,
    public AccountType?: string,
    public AccountStatus?: string,
    public Account?: string,
    public Accounts?: string
  ) { }

}
