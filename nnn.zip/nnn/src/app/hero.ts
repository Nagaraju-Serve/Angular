export class Hero {

    constructor(
      public id: number,
      public BankName: string,
      public BranchName?: string,
      public IFSCCode?: string
    ) {  }
  
  }